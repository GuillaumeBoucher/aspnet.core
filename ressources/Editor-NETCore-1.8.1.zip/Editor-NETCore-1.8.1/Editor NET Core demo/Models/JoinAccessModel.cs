﻿using DataTables;

namespace EditorNetCoreDemo.Models
{
    public class JoinAccessModel
    {
        public string id { get; set; }

        public string name { get; set; }
    }
}