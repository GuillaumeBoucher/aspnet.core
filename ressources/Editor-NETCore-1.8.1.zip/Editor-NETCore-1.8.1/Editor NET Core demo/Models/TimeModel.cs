﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EditorNetCoreDemo.Models
{
    public class TimeModel
    {
        public string first_name { get; set; }
        public string last_name { get; set; }
        public string city { get; set; }
        public string shift_start { get; set; }
        public string shift_end { get; set; }
    }
}