﻿using DataTables;

namespace EditorNetCoreDemo.Models
{
    public class TableOnlyDataModel
    {
        public string first_name { get; set; }

        public string last_name { get; set; }

        public string updated_date { get; set; }
    }
}