﻿using DataTables;

namespace EditorNetCoreDemo.Models
{
    public class ToDoModel
    {
        public string item { get; set; }

        public bool done { get; set; }

        public int priority { get; set; }
    }
}