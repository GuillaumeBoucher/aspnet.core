﻿using System;

namespace EditorNetCoreDemo.Models
{
    public class DatesModel
    {
        public string first_name { get; set; }

        public string last_name { get; set; }

        public string updated_date { get; set; }

        public string registered_date { get; set; }
    }
}