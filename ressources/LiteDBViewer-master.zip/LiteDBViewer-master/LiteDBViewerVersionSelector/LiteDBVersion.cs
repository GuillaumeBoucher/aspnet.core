﻿namespace LiteDBViewerVersionSelector
{
    public enum LiteDBVersion
    {
        Unknown,
        LiteDB_0_9,
        LiteDB_1_0,
        LiteDB_2_0RC,
        LiteDB_2_0,
        LiteDB_3_0__4_0,
    }
}